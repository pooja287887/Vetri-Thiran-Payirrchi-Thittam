from .config import GEMINI_API_KEY,GEMINI_PRO_MODEL
def update_workout_plan(original_plan,feedback,goal,age):
    if not GEMINI_API_KEY: return original_plan+"\n\nFeedback note: "+feedback
    from google import genai
    prompt=f'''Revise this 7-day wellness plan using the feedback.
Age: {age}; Goal: {goal}; Feedback: {feedback}
Keep 7 days. Do not add calorie restriction, rapid weight loss, supplements or medical treatment.
For users under 18, avoid weight-focused recommendations. Return only the revised plan.
Original:
{original_plan}'''
    return genai.Client(api_key=GEMINI_API_KEY).models.generate_content(model=GEMINI_PRO_MODEL,contents=prompt).text.strip()
