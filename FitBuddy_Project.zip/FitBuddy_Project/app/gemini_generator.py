from .config import GEMINI_API_KEY,GEMINI_PRO_MODEL
def _client():
    if not GEMINI_API_KEY: return None
    from google import genai
    return genai.Client(api_key=GEMINI_API_KEY)
def generate_workout_gemini(username,age,weight,goal,intensity):
    client=_client()
    prompt=f'''You are FitBuddy, a general wellness planning assistant.
Create a safe, practical 7-day activity plan.
Name: {username}
Age: {age}
Goal: {goal}
Intensity: {intensity}
Weight: {weight if weight is not None else "not provided"}
Include exactly 7 labeled days. Each day needs focus, warm-up, main activity, and cool-down/recovery.
Do not prescribe calorie restriction, rapid weight loss, supplements, or medical treatment.
For users under 18, avoid weight-focused advice and emphasize age-appropriate activity, rest, hydration and support from a parent/guardian or qualified professional when appropriate.
'''
    if not client: return fallback_plan(goal,intensity)
    return client.models.generate_content(model=GEMINI_PRO_MODEL,contents=prompt).text.strip()
def fallback_plan(goal,intensity):
    return f'''7-Day FitBuddy Wellness Plan
Goal: {goal} | Intensity: {intensity}
Day 1 - Full Body: 5-10 min warm-up; squats, wall push-ups, glute bridges and easy walking; gentle cool-down.
Day 2 - Cardio & Mobility: easy walk; 20-30 min comfortable cardio; mobility and breathing.
Day 3 - Strength Basics: warm-up; controlled bodyweight movements and light resistance; stretching.
Day 4 - Recovery: easy movement and gentle mobility.
Day 5 - Full Body: repeat basic strength movements with controlled technique; cool-down.
Day 6 - Fun Cardio: walking, cycling, dancing or another enjoyable activity at a comfortable pace.
Day 7 - Rest & Recovery: rest, hydrate, sleep well and use light mobility if comfortable.
'''
