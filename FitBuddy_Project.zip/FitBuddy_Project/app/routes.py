from fastapi import APIRouter,Depends,Form,Request
from fastapi.responses import HTMLResponse,RedirectResponse
from sqlalchemy.orm import Session
from .database import get_db,save_user,save_plan,get_latest_plan,update_plan,get_all_users
from .schemas import UserInput,FeedbackRequest
from .gemini_generator import generate_workout_gemini
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .updated_plan import update_workout_plan
router=APIRouter()
@router.get("/",response_class=HTMLResponse)
def home(request:Request): return request.app.state.templates.TemplateResponse("index.html",{"request":request})
@router.post("/generate-workout",response_class=HTMLResponse)
def generate_workout(request:Request,username:str=Form(...),user_id:str=Form(...),age:int=Form(...),weight:float|None=Form(None),goal:str=Form(...),intensity:str=Form(...),db:Session=Depends(get_db)):
    data=UserInput(username=username,user_id=user_id,age=age,weight=weight,goal=goal,intensity=intensity)
    save_user(db,data); plan=generate_workout_gemini(data.username,data.age,data.weight,data.goal,data.intensity); tip=generate_nutrition_tip_with_flash(data.goal,data.age); save_plan(db,data.user_id,plan,tip)
    return request.app.state.templates.TemplateResponse("result.html",{"request":request,"user":data,"workout_plan":plan,"nutrition_tip":tip})
@router.post("/submit-feedback",response_class=HTMLResponse)
def submit_feedback(request:Request,user_id:str=Form(...),feedback:str=Form(...),db:Session=Depends(get_db)):
    req=FeedbackRequest(user_id=user_id,feedback=feedback); plan=get_latest_plan(db,req.user_id)
    if not plan: return RedirectResponse("/",status_code=303)
    user=next((u for u in get_all_users(db) if u.user_id==req.user_id),None)
    revised=update_workout_plan(plan.original_plan,req.feedback,user.goal,user.age); update_plan(db,plan,revised,req.feedback)
    return request.app.state.templates.TemplateResponse("result.html",{"request":request,"user":user,"workout_plan":revised,"nutrition_tip":plan.nutrition_tip,"updated":True})
@router.get("/view-all-users",response_class=HTMLResponse)
def view_all_users(request:Request,db:Session=Depends(get_db)):
    return request.app.state.templates.TemplateResponse("all_users.html",{"request":request,"rows":[{"user":u,"plan":get_latest_plan(db,u.user_id)} for u in get_all_users(db)]})
