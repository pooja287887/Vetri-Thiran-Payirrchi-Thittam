from .config import GEMINI_API_KEY,GEMINI_FLASH_MODEL
def generate_nutrition_tip_with_flash(goal,age):
    prompt=f'''Give one short practical nutrition or recovery tip for a wellness app.
Goal: {goal}; Age: {age}. Avoid calorie restriction, weight-loss targets, supplements and medical claims.
Emphasize balanced meals, hydration, sleep and sustainable habits. Return 2-4 sentences.'''
    if not GEMINI_API_KEY:
        return "Prioritize regular balanced meals, drink water throughout the day, and get enough sleep for recovery. For personal nutrition needs, a qualified health professional can provide individualized advice."
    from google import genai
    return genai.Client(api_key=GEMINI_API_KEY).models.generate_content(model=GEMINI_FLASH_MODEL,contents=prompt).text.strip()
