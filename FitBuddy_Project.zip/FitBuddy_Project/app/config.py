import os
from dotenv import load_dotenv
load_dotenv()
DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///./fitbuddy.db")
GEMINI_API_KEY=os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
GEMINI_PRO_MODEL=os.getenv("GEMINI_PRO_MODEL","gemini-2.5-flash")
GEMINI_FLASH_MODEL=os.getenv("GEMINI_FLASH_MODEL","gemini-2.5-flash")
