from pydantic import BaseModel, Field, field_validator
class UserInput(BaseModel):
    username:str=Field(min_length=1,max_length=120)
    user_id:str=Field(min_length=1,max_length=100)
    age:int=Field(ge=13,le=120)
    weight:float|None=Field(default=None,ge=20,le=500)
    goal:str=Field(min_length=2,max_length=100)
    intensity:str
    @field_validator("intensity")
    @classmethod
    def valid_intensity(cls,v):
        v=v.lower().strip()
        if v not in {"low","medium","high"}: raise ValueError("Intensity must be low, medium, or high.")
        return v
class FeedbackRequest(BaseModel):
    user_id:str=Field(min_length=1,max_length=100)
    feedback:str=Field(min_length=2,max_length=2000)
