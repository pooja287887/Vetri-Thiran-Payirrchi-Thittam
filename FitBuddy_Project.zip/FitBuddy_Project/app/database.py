from datetime import datetime
from sqlalchemy import create_engine,String,Integer,Float,Text,DateTime,ForeignKey
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker,Session
from .config import DATABASE_URL
engine=create_engine(DATABASE_URL,connect_args={"check_same_thread":False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
class Base(DeclarativeBase): pass
class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    user_id:Mapped[str]=mapped_column(String(100),unique=True,index=True)
    username:Mapped[str]=mapped_column(String(120))
    age:Mapped[int|None]=mapped_column(Integer,nullable=True)
    weight:Mapped[float|None]=mapped_column(Float,nullable=True)
    goal:Mapped[str]=mapped_column(String(100))
    intensity:Mapped[str]=mapped_column(String(20))
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Plan(Base):
    __tablename__="plans"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    user_id:Mapped[str]=mapped_column(String(100),ForeignKey("users.user_id"),index=True)
    original_plan:Mapped[str]=mapped_column(Text)
    updated_plan:Mapped[str|None]=mapped_column(Text,nullable=True)
    nutrition_tip:Mapped[str]=mapped_column(Text)
    feedback:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
Base.metadata.create_all(engine)
def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()
def save_user(db,data):
    u=db.query(User).filter(User.user_id==data.user_id).first() or User(user_id=data.user_id)
    db.add(u)
    for k in ("username","age","weight","goal","intensity"): setattr(u,k,getattr(data,k))
    db.commit(); db.refresh(u); return u
def save_plan(db,user_id,original_plan,nutrition_tip):
    p=Plan(user_id=user_id,original_plan=original_plan,nutrition_tip=nutrition_tip); db.add(p); db.commit(); db.refresh(p); return p
def get_latest_plan(db,user_id): return db.query(Plan).filter(Plan.user_id==user_id).order_by(Plan.id.desc()).first()
def update_plan(db,p,updated,feedback):
    p.updated_plan=updated; p.feedback=feedback; db.commit(); db.refresh(p); return p
def get_all_users(db): return db.query(User).order_by(User.id.desc()).all()
