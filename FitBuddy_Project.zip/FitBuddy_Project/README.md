# FitBuddy – AI Fitness Plan Generator
Complete FastAPI + Jinja2 + SQLite + Gemini implementation based on the supplied FitBuddy documentation.

## Setup
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000` and `/docs`.

Run tests:
```powershell
pytest -q
```

The supplied documentation specifies Gemini 1.5 Pro for workout generation/updates, Gemini Flash for nutrition tips, FastAPI, Jinja2, SQLAlchemy and SQLite. This implementation keeps that architecture but uses the current `google-genai` SDK and configurable model names. The app has a safe local fallback when no API key is configured.

Administrator privileges are normally unnecessary; if Windows permissions cause an issue, run PowerShell/Windows Terminal as Administrator.
